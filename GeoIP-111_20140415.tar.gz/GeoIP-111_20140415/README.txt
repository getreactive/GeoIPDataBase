Note - requires C API 1.1.6 and above.
